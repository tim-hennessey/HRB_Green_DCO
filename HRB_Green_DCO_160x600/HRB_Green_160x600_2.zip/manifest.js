FT.manifest({
	"filename":"index.html",
	"width":160,
	"height":600,
	"clickTagCount":1,
	"instantAds":[
		{"name":"dynamicText", "type":"text", "default":"More<br>parents<br>can file<br>free with<br>H&R Block<br>Online<br>than<br>TurboTax."},
		{"name":"dynamicCTA", "type":"text", "default":"File online now"},
		{"name":"fontSize", "type":"text", "default":"24px"},
		{"name":"dynamicLegal", "type":"text", "default":"Optional loan from Axos Bank within minutes of filing.<br>Not your tax refund."},
		{"name":"dynamicURL", "type":"text", "default":"https://www.example.com/"}
	]
});
