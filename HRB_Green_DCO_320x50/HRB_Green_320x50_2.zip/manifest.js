FT.manifest({
	"filename":"index.html",
	"width":320,
	"height":50,
	"clickTagCount":1,
	"instantAds":[
		{"name":"dynamicText", "type":"text", "default":"More parents can file free with<br>H&R Block Online than TurboTax."},
		{"name":"dynamicCTA", "type":"text", "default":"File online now"},
		{"name":"fontSize", "type":"text", "default":"13px"},
		{"name":"dynamicLegal", "type":"text", "default":"Optional loan from Axos Bank within minutes of filing.<br>Not your tax refund."},
		{"name":"dynamicURL", "type":"text", "default":"https://www.example.com/"}
	]
});
