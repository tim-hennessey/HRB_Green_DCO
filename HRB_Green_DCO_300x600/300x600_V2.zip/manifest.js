FT.manifest({
	"filename":"index.html",
	"width":300,
	"height":600,
	"clickTagCount":1,
	"instantAds":[
		{"name":"dynamicText", "type":"text", "default":"More parents can file free with H&R Block Online than TurboTax."},
		{"name":"dynamicLegal", "type":"text", "default":"Optional loan from Axos Bank within minutes of filing.<br>Not your tax refund."},
		{"name":"dynamicCTA", "type":"text", "default":"File online now"},
		{"name":"fontSize", "type":"text", "default":"51px"},
		{"name":"dynamicURL", "type":"text", "default":"https://www.example.com/"}


	]
});




