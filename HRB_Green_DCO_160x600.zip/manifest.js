FT.manifest({
	"filename":"index.html",
	"width":160,
	"height":600,
	"clickTagCount":1,
	"instantAds":[
		{"name":"dynamicText", "type":"text", "default":"More parents can file free with H&R Block Online than TurboTax."},
		{"name":"dynamicCTA", "type":"text", "default":"File online now"},
		{"name":"fontSize", "type":"text", "default":"24px"}
	]
});
