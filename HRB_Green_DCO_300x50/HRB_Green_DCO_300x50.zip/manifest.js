FT.manifest({
	"filename":"index.html",
	"width":300,
	"height":50,
	"clickTagCount":1,
	"instantAds":[
		{"name":"dynamicText", "type":"text", "default":"More parents can file free with<br>H&R Block Online than TurboTax."},
		{"name":"fontSize", "type":"text", "default":"14px"}
	]
});
